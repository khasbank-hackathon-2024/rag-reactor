These 2 subfolders contain all the scripts and performance documents for the 2 graphs used for the scrapers. 
In particular:
* __GenerateScraper__: contains the benchmarks for GenerateScraper class
* __SmartScraper__:  contains the benchamrks for SmartScraper class